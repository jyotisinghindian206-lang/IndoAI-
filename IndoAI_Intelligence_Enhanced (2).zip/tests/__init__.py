"""Indo AI regression tests."""
